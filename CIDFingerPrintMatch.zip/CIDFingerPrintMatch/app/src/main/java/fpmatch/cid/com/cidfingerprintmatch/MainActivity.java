package fpmatch.cid.com.cidfingerprintmatch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.R.*;
import android.util.Log;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.credenceid.biometrics.Biometrics;
import com.credenceid.biometrics.BiometricsActivity;
import com.credenceid.biometrics.BiometricsManager;
import com.credenceid.biometrics.Biometrics.ScanType;
import com.credenceid.biometrics.Biometrics.FmdFormat;

public class MainActivity extends Activity {

    public ImageView mMainFingerPrint;
    public ImageView mSecondFingerPrint;

    private BiometricsManager mBioMetrics;
    byte[] mFinger1;
    byte[] mFinger2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBioMetrics = new BiometricsManager(this);

        mBioMetrics.initializeBiometrics(new Biometrics.OnInitializedListener() {
            @Override
            public void onInitialized(Biometrics.ResultCode resultCode, String s, String s1) {
                if (Biometrics.ResultCode.OK != resultCode) {
                    Toast.makeText(getApplicationContext(), "ERROR: BioMetrics Initialization Failed !!!!", Toast.LENGTH_LONG).show();
                }
            }
        });
        //}

        mMainFingerPrint = (ImageView) findViewById(R.id.main_fingerprint);
        mSecondFingerPrint = (ImageView) findViewById(R.id.second_fingerprint);

        final Button mainbtn = findViewById(R.id.maincapturebtn);
        mainbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mBioMetrics.grabFingerprint(ScanType.SINGLE_FINGER, new Biometrics.OnFingerprintGrabbedFullListener() {
                    @Override
                    public void onFingerprintGrabbed(Biometrics.ResultCode resultCode, Bitmap bitmap, Bitmap bitmap1, Bitmap bitmap2, byte[] bytes, byte[] bytes1, byte[] bytes2, String s, String s1, String s2, String s3) {
                        //got bitmap
                        mBioMetrics.convertToFmd(bitmap, FmdFormat.ISO_19794_2_2005, new Biometrics.OnConvertToFmdListener() {
                            @Override
                            public void onConvertToFmd(Biometrics.ResultCode resultCode, byte[] bytes) {

                                if (Biometrics.ResultCode.OK == resultCode) {
                                    Toast.makeText(getApplicationContext(), "Finger Print Captured !!!!", Toast.LENGTH_SHORT).show();
                                    mFinger1 = bytes;
                                }
                            }
                        });
                    }

                    @Override
                    public void onCloseFingerprintReader(Biometrics.ResultCode resultCode, Biometrics.CloseReasonCode closeReasonCode) {

                    }
                });
            }
        });

        final Button secondbtn = findViewById(R.id.secondcapturebtn);
        secondbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mBioMetrics.grabFingerprint(ScanType.SINGLE_FINGER, new Biometrics.OnFingerprintGrabbedFullListener() {
                    @Override
                    public void onFingerprintGrabbed(Biometrics.ResultCode resultCode, Bitmap bitmap, Bitmap bitmap1, Bitmap bitmap2, byte[] bytes, byte[] bytes1, byte[] bytes2, String s, String s1, String s2, String s3) {
                        //got bitmap
                        mBioMetrics.convertToFmd(bitmap, FmdFormat.ISO_19794_2_2005, new Biometrics.OnConvertToFmdListener() {
                            @Override
                            public void onConvertToFmd(Biometrics.ResultCode resultCode, byte[] bytes) {

                                if (Biometrics.ResultCode.OK == resultCode) {
                                    Toast.makeText(getApplicationContext(), "Finger Print Captured !!!!", Toast.LENGTH_SHORT).show();
                                    mFinger2 = bytes;
                                }
                            }
                        });
                    }

                    @Override
                    public void onCloseFingerprintReader(Biometrics.ResultCode resultCode, Biometrics.CloseReasonCode closeReasonCode) {

                    }
                });
            }
        });

        final Button verifybtn = findViewById(R.id.verifybtn);
        verifybtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mBioMetrics.compareFmd(mFinger1, mFinger2, FmdFormat.ISO_19794_2_2005, new Biometrics.OnCompareFmdListener() {
                    @Override
                    public void onCompareFmd(Biometrics.ResultCode resultCode, float v) {
                        //if ( (Biometrics.ResultCode.OK == resultCode) || (0 == v) ) {
                        if ( (Biometrics.ResultCode.OK == resultCode) ) {
                            Toast.makeText(getApplicationContext(), "Finger Print Matched !!!!", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "Finger Print Did Not Match !!!!", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }
}